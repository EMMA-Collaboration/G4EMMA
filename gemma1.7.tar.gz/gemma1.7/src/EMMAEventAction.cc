//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id: EMMAEventAction.cc,v 1.10 2007-05-17 09:55:14 duns Exp $
// --------------------------------------------------------------
//

#include "EMMAEventAction.hh"
#include "EMMAEventActionMessenger.hh"
#ifdef G4ANALYSIS_USE
#include "EMMAAnalysisManager.hh"
#endif // G4ANALYSIS_USE

#include "G4Event.hh"
#include "G4EventManager.hh"
#include "G4HCofThisEvent.hh"
#include "G4VHitsCollection.hh"
#include "G4TrajectoryContainer.hh"
#include "G4Trajectory.hh"
#include "G4VVisManager.hh"
#include "G4SDManager.hh"
#include "G4UImanager.hh"
#include "G4ios.hh"

#include "EMMADriftChamberHit.hh"

using namespace std;

//global variable
extern G4String UserDir;


EMMAEventAction::EMMAEventAction()
:fp_hitpos(0),fp_hitangle(0)
{
  G4String colName;
  G4SDManager* SDman = G4SDManager::GetSDMpointer();
  DHC2ID = SDman->GetCollectionID(colName="detector/detectorColl");
  verboseLevel = 1;
  messenger = new EMMAEventActionMessenger(this);

#ifdef G4ANALYSIS_USE
 // Create root files for analysis

  //call root file
  EMMAAnalysisManager* analysisManager = EMMAAnalysisManager::getInstance();
  rootfile = analysisManager->getRootfile();

  //create root histograms
  fp_hitpos = new TH2F("hitpos","Focal plane hit position",6000,-30,30,6000,-30,30);
  fp_hitpos->GetXaxis()->SetTitle("X position (mm)");	//axis labels
  fp_hitpos->GetYaxis()->SetTitle("Y position (mm)");
  fp_hitangle = new TH1F("hitangle","Focal plane hit angle",100,0,10);
  fp_hitangle->GetXaxis()->SetTitle("Theta (deg)");	//axis labels
  fp_hitangle->GetYaxis()->SetTitle("Counts");
  
  //call root tree and creates branches to store event by event data
  fp_tree = analysisManager->getRoottree();
  fp_tree->Branch("fp_pos",&fp_pos,"fp_pos[2]/D");
  fp_tree->Branch("fp_theta",&fp_theta,"fp_theta/D");
  
#endif // G4ANALYSIS_USE
}

EMMAEventAction::~EMMAEventAction()
{
#ifdef G4ANALYSIS_USE
  EMMAAnalysisManager::dispose();
  rootfile->Write(); //writes all histograms and trees to file (also ones created in SteppingAction.cc
  rootfile->Close(); //must close root file
  delete rootfile;
#endif // G4ANALYSIS_USE
  delete messenger;
}

void EMMAEventAction::BeginOfEventAction(const G4Event* evt)
{

  G4cout<<"Start event: "<<evt->GetEventID()<<G4endl;

}

void EMMAEventAction::EndOfEventAction(const G4Event* evt)
{
  G4HCofThisEvent * HCE = evt->GetHCofThisEvent();
  EMMADriftChamberHitsCollection* DHC2 = 0;
  if(HCE)
  {
    DHC2 = (EMMADriftChamberHitsCollection*)(HCE->GetHC(DHC2ID));
  }

  // Diagnostics

  if (verboseLevel==0 || evt->GetEventID() % verboseLevel != 0) return;

  G4PrimaryParticle* primary = evt->GetPrimaryVertex(0)->GetPrimary(0);
  G4cout << G4endl
         << "\t>>> Event " << evt->GetEventID() << " >>> Simulation truth : "
         << primary->GetG4code()->GetParticleName()
         << " " << primary->GetMomentum() << G4endl;


  if(DHC2)
  {
    int n_hit = DHC2->entries();
    G4cout << "Stopping Block has " << n_hit << " hits." << G4endl;
    for(int i2=0;i2<5;i2++)
    {
      for(int i1=0;i1<min(1,n_hit);i1++)
      {
        EMMADriftChamberHit* aHit = (*DHC2)[i1];
        if(aHit->GetLayerID()==i2){
          aHit->Print();
          
#ifdef G4ANALYSIS_USE
            localPos = aHit->GetLocalPos();	//local position at focal plane
            theta = aHit->GetTheta()/deg; //angle at focal place
            if (fp_hitpos) fp_hitpos->Fill(localPos.x()/mm, localPos.y()/mm); //fill histogram
            if (fp_hitangle) fp_hitangle->Fill(theta); //fill histogram
            if (fp_tree){ //fill branch with position and angle for each event
              fp_pos[0]=localPos.x()/mm;
              fp_pos[1]=localPos.y()/mm;
              fp_theta=theta;
              fp_tree->Fill();
            }
#endif // G4ANALYSIS_USE
        }
      }
    }
  }
}


