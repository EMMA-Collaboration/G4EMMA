rm Makefile
rm CMakeCache.txt
rm -r CMakeFiles
rm cmake_install.cmake
cmake -DGeant4_DIR=/usr/local/geant/geant4.9.6.p02 /Users/naomig/Documents/EMMA/gemma1.5
