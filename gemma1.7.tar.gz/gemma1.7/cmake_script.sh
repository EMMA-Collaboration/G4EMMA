rm Makefile
rm CMakeCache.txt
rm -RI CMakeFiles
rm cmake_install.cmake
cmake -DGeant4_DIR=/usr/local/GEANT4/geant4.9.6.p04 /home/mwilliams/Documents/EMMA/gemma1.7
