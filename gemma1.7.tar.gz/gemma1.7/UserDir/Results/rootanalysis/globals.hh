#ifndef __GLOBALS_HH
#define __GLOBALS_HH

#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

const int ARRAYDIM = 99999;

#endif
